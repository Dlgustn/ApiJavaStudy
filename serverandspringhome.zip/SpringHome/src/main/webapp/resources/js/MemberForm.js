/**
 * 
 */

 function pageMoveListFnc(){
	 location.href = "./list.do";
 }
 
 